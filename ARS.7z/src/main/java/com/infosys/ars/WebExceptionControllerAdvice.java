package com.infosys.ars;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.ModelAndView;

import com.infosys.ars.domain.ErrorDetails;


@ControllerAdvice
public class WebExceptionControllerAdvice {
	@ExceptionHandler(HttpClientErrorException.class)
	public ModelAndView serviceExceptionHandler(HttpClientErrorException ex) {
		System.out.println("ex.getRawStatusCode()" +ex.getRawStatusCode());
		System.out.println(ex.getResponseBodyAsString());
		ErrorDetails errObj = new ErrorDetails();
		errObj.setErrorCode(ex.getRawStatusCode());
		errObj.setErrorMessage(ex.getResponseBodyAsString());
		
		return new ModelAndView("failure", "command",errObj);
	}
	
	
	@ExceptionHandler(Exception.class)
	public ModelAndView webExceptionHandler(Exception ex) {
		ex.printStackTrace();
		System.out.println(ex.getMessage());
		ErrorDetails errObj = new ErrorDetails();
		errObj.setErrorMessage(ex.getMessage());

		return new ModelAndView("failure", "command",errObj);
	}
}
