package com.infosys.ars;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import com.infosys.ars.controller.CustomerUserDetailsService;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private CustomerUserDetailsService userDetailsService;

	@Override
	protected void configure(HttpSecurity http) throws Exception {


		http.authorizeRequests()

		.antMatchers("/login?logout").fullyAuthenticated()

		.and().formLogin().loginPage("/login").defaultSuccessUrl("/home").permitAll()

		.and().logout().permitAll().and().csrf();
		       
		         http.authorizeRequests()

					.antMatchers("/ars").fullyAuthenticated()

					.and().formLogin().loginPage("/login").permitAll()

					.and().logout().permitAll().and().csrf();
		http.csrf().disable();

	}

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {

		auth.userDetailsService(userDetailsService);

	}

}
