/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infosys.ars.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class Booking {
	private String userName;
	private String firstName;
	private String departureDate;
	private String departureCity;
	private String departureTime;
	private String fare;
	private String destinationCity;
	private Integer seats;
	private int pnr;
	private String passenger1;
	private String passenger2;
	private String passenger3;
	private String gender1;
	private String gender2;
	private String gender3;

	@NotNull
	@Pattern(regexp = "^\\d{1,2}", message = "Age must be in 0-99 range")
	
	private String age1 ="0";

	@NotNull
	@Pattern(regexp = "^\\d{1,2}", message = "Age must be in 0-99 range")
	private String age2 = "0";

	@NotNull
	@Pattern(regexp = "^\\d{1,2}", message = "Age must be in 0-99 range")
	private String age3 ="0";
	
	private String validationErrorMessage;

	public int getPnr() {
		return pnr;
	}

	public void setPnr(int pnr) {
		this.pnr = pnr;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getDepartureCity() {
		return departureCity;
	}

	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getFare() {
		return fare;
	}

	public void setFare(String fare) {
		this.fare = fare;
	}

	public String getDestinationCity() {
		return destinationCity;
	}

	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}

	public Integer getSeats() {
		return seats;
	}

	public void setSeats(Integer seats) {
		this.seats = seats;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassenger1() {
		return passenger1;
	}

	public void setPassenger1(String passenger1) {
		this.passenger1 = passenger1;
	}

	public String getPassenger2() {
		return passenger2;
	}

	public void setPassenger2(String passenger2) {
		this.passenger2 = passenger2;
	}

	public String getPassenger3() {
		return passenger3;
	}

	public void setPassenger3(String passenger3) {
		this.passenger3 = passenger3;
	}

	public String getGender1() {
		return gender1;
	}

	public void setGender1(String gender1) {
		this.gender1 = gender1;
	}

	public String getGender2() {
		return gender2;
	}

	public void setGender2(String gender2) {
		this.gender2 = gender2;
	}

	public String getGender3() {
		return gender3;
	}

	public void setGender3(String gender3) {
		this.gender3 = gender3;
	}

	public String getAge1() {
		return age1;
	}

	public void setAge1(String age1) {
		this.age1 = age1;
	}

	public String getAge2() {
		return age2;
	}

	public void setAge2(String age2) {
		this.age2 = age2;
	}

	public String getAge3() {
		return age3;
	}

	public void setAge3(String age3) {
		this.age3 = age3;
	}

	public String getValidationErrorMessage() {
		return validationErrorMessage;
	}

	public void setValidationErrorMessage(String validationErrorMessage) {
		this.validationErrorMessage = validationErrorMessage;
	}

	@Override
	public String toString() {
		return "Booking [userName=" + userName + ", firstName=" + firstName + ", departureDate=" + departureDate
				+ ", departureCity=" + departureCity + ", departureTime=" + departureTime + ", fare=" + fare
				+ ", destinationCity=" + destinationCity + ", seats=" + seats + ", pnr=" + pnr + ", passenger1="
				+ passenger1 + ", passenger2=" + passenger2 + ", passenger3=" + passenger3 + ", gender1=" + gender1
				+ ", gender2=" + gender2 + ", gender3=" + gender3 + ", age1=" + age1 + ", age2=" + age2 + ", age3="
				+ age3 + ", validationErrorMessage=" + validationErrorMessage + "]";
	}

}
