/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infosys.ars.domain;

import org.hibernate.validator.constraints.NotEmpty;

public class SearchFlights {
	@NotEmpty(message = "Please enter the Source City")
	private String source;

	@NotEmpty(message = "Please enter the Destination City")
	private String destination;

	@NotEmpty(message = "Please enter the Journey Date")
	private String journeyDate;
	
	private String fare;
	private String validationDateError;
	
	public String getFare() {
		return fare;
	}

	public void setFare(String fare) {
		this.fare = fare;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(String journeyDate) {
		this.journeyDate = journeyDate;
	}
	public String getValidationDateError() {
		return validationDateError;
	}

	public void setValidationDateError(String validationDateError) {
		this.validationDateError = validationDateError;
	}

}
