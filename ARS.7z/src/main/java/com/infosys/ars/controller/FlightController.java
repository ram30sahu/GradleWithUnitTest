/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infosys.ars.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.infosys.ars.domain.Booking;
import com.infosys.ars.domain.Flights;
import com.infosys.ars.domain.SearchFlights;

@Controller
public class FlightController {
	@Autowired
	private RestTemplate restTemplate;
	@Value("${restServer}")
	private String restUrl;

	@RequestMapping(value = "/SearchFlights.htm", method = RequestMethod.POST)
	public ModelAndView flightSearch(@Valid @ModelAttribute("command") SearchFlights searchFlights,
			BindingResult bindingResult, ModelMap model, @RequestParam("user") String name) {

		if (bindingResult.hasErrors()) {
			return new ModelAndView("searchFlights", "command", searchFlights);

		} else if (validateDate(searchFlights)) {

			@SuppressWarnings("unchecked")
			List<Flights> availableFlights = restTemplate.getForObject(restUrl + "/flights/" + searchFlights.getSource()
					+ "/" + searchFlights.getDestination() + "/" + searchFlights.getJourneyDate(), List.class);

			model.addAttribute("availableFlights", availableFlights);
			model.addAttribute("size", availableFlights.size());
			model.addAttribute("userName", name);
		}
		return new ModelAndView("searchFlights", "command", searchFlights);
	}

	@RequestMapping(value = "/Proceed.htm", method = RequestMethod.GET)
	public ModelAndView proceed(ModelMap model, @RequestParam("fare") String fare, @RequestParam("from") String from,
			@RequestParam("to") String to, @RequestParam("jdate") String jdate, @RequestParam("time") String time,
			@RequestParam("seat") Integer seat, @RequestParam("user") String username,
			@RequestParam("fid") String flightId) {

		Booking bk = new Booking();
		bk.setDepartureCity(from);
		bk.setDepartureDate(jdate);
		bk.setDepartureTime(time);
		bk.setDestinationCity(to);
		bk.setFare(fare);
		bk.setSeats(seat);
		bk.setFirstName(flightId);

		model.addAttribute("user", username);

		return new ModelAndView("booking", "command", bk);
	}

	private boolean validateDate(SearchFlights searchFlights) {
		try {
			LocalDate inputDate = LocalDate.parse(searchFlights.getJourneyDate(),
					DateTimeFormatter.ofPattern("dd-MM-yyyy"));
			if (inputDate.isBefore(LocalDate.now())) {
				searchFlights.setValidationDateError("Journey Date can not be a past date.");
				return false;
			}
		} catch (Exception ex) {
			searchFlights.setValidationDateError("Please enter date in dd-mm-yyyy.");
			return false;
		}

		return true;
	}
}
