/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infosys.ars.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.infosys.ars.domain.Login;
import com.infosys.ars.domain.SearchFlights;

@Controller
@SessionAttributes("userName")
public class LoginController {
	

	//@Autowired
	//private RestTemplate restTemplate;

	/*@RequestMapping(value = "/login.htm", method = RequestMethod.POST)
	public ModelAndView getLoginDetails(ModelMap model,@RequestParam String userName) {
	
		return new ModelAndView("home");
	}*/

	@RequestMapping(value = "/searchFlightsService.htm", method = RequestMethod.GET)
	public ModelAndView processLoginDetails(ModelMap model,@SessionAttribute("userName")String userName) {
		
				model.addAttribute("userName",userName );
				
				return new ModelAndView("searchFlights", "command", new SearchFlights());
			
		}

	

}
