package com.infosys.ars.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.ars.domain.Passenger;
import com.infosys.ars.domain.Ticket;
import com.infosys.ars.repository.PassengerRepository;
import com.infosys.ars.repository.TicketRepository;

@RestController
@RequestMapping("/passengers")
public class BookingRESTService {
	@Autowired
	private PassengerRepository passengerRepository;
	
	@Autowired
	private TicketRepository ticketRepository;

	@RequestMapping(value = "/{age}/{gender}/{passengerName}/{pnr}", method = RequestMethod.GET, headers = "Accept=application/json")
	public String passengerDetails(@PathVariable String age, @PathVariable String gender, @PathVariable String passengerName,
			@PathVariable String pnr) {
		Passenger passenger = new Passenger();
		Ticket t = new Ticket();
		t.setPnr(pnr);
		ticketRepository.saveAndFlush(t);
		passenger.setTicket(t);
		passenger.setPassengerAge(age);
		passenger.setPassengerGender(gender);
		passenger.setPassengerName(passengerName);
		passengerRepository.saveAndFlush(passenger);
		return "success";
	}
}
