/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infosys.ars.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.infosys.ars.domain.Booking;
import com.infosys.ars.domain.Customer;
import com.infosys.ars.domain.Flights;
import com.infosys.ars.domain.Ticket;
import com.infosys.ars.repository.FlightsRepository;
import com.infosys.ars.repository.TicketRepository;

@Controller
public class BookingController {
	@Autowired
	private TicketRepository ticketRepository;
	@Autowired
	private FlightsRepository flightRepository;
	@Autowired
	private Ticket ticket;
	@Autowired
	private RestTemplate restTemplate;
	@Value("${restServer}")
	private String restUrl;

	@RequestMapping(value = "/bookingprocess.htm", method = RequestMethod.POST)
	public ModelAndView bookingProcess(@Valid @ModelAttribute("command") Booking newBooking,
			BindingResult bindingResult, ModelMap model, @RequestParam("seat") String seat,
			@RequestParam("from") String from, @RequestParam("to") String to, @RequestParam("fare") String fare,
			@RequestParam("fname") String fname, @RequestParam("user") String user, @RequestParam("jtime") String jtime,
			@RequestParam("jdate") String jdate) {
		double sum = 0;
		model.addAttribute("user", user);
		int pnr = (int) (Math.random() * 1858955);
		model.addAttribute("pnr", pnr);
		Calendar currentDate = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		String dateNow = formatter.format(currentDate.getTime());
		ticket.setBookingDate(dateNow);
		ticket.setDepartureDate(jdate);
		ticket.setDepartureTime(jtime);
		Flights f = new Flights();
		f.setFlightId(fname);
		ticket.setFlight(f);
		ticket.setPnr("" + pnr);
		Customer customer = new Customer();
		customer.setUserId(user);
		ticket.setCustomer(customer);

		int noOfSeats = 0;
		String str1 = "" + pnr;

		if (bindingResult.hasErrors()) {
			newBooking.setDepartureCity(from);
			newBooking.setDepartureDate(jdate);
			newBooking.setDepartureTime(jtime);
			newBooking.setDestinationCity(to);
			newBooking.setFare(fare);
			newBooking.setSeats(Integer.parseInt(seat));
			newBooking.setUserName(user);
			newBooking.setFirstName(fname);
			
			return new ModelAndView("booking", "command", newBooking);

		}
		if (newBooking.getAge1() != null && newBooking.getGender1() != null && newBooking.getPassenger1() != null
				&& newBooking.getGender1().length() != 0 && newBooking.getPassenger1().length() != 0) {

			sum += Double.parseDouble(fare);
			noOfSeats++;

			String restresult = restTemplate.getForObject(restUrl + "/passengers/" + newBooking.getAge1() + "/"
					+ newBooking.getGender1() + "/" + newBooking.getPassenger1() + "/" + str1, String.class);
			if (restresult == "failure") {
				return new ModelAndView("failure", "command", "Invalid Passenger Details");
			}

		} else {
			newBooking.setDepartureCity(from);
			newBooking.setDepartureDate(jdate);
			newBooking.setDepartureTime(jtime);
			newBooking.setDestinationCity(to);
			newBooking.setFare(fare);
			newBooking.setSeats(Integer.parseInt(seat));
			newBooking.setUserName(user);
			newBooking.setFirstName(fname);
			/*
			 * if (newBooking.getAge1()==0 || newBooking.getAge1()>100)
			 * newBooking.setValidationErrorMessage("Please enter valid age");
			 * else
			 */
			newBooking.setValidationErrorMessage("Please enter valid Passenger Details");
			return new ModelAndView("booking", "command", newBooking);

		}

		if (newBooking.getPassenger2().length() != 0 && newBooking.getPassenger2() != null) {

			sum += Double.parseDouble(fare);
			noOfSeats++;
			System.out.println("p2" + newBooking.getPassenger2());

			String restresult = restTemplate.getForObject(restUrl + "/passengers/" + newBooking.getAge2() + "/"
					+ newBooking.getGender2() + "/" + newBooking.getPassenger2() + "/" + str1, String.class);
			if (restresult == "failure") {
				return new ModelAndView("failure", "command", "Invalid Passenger Details");
			}

		}

		if (newBooking.getPassenger3().length() != 0 && newBooking.getPassenger3() != null) {

			sum += Double.parseDouble(fare);
			noOfSeats++;
			System.out.println("p3" + newBooking.getPassenger3());

			String restresult = restTemplate.getForObject(restUrl + "/passengers/" + newBooking.getAge3() + "/"
					+ newBooking.getGender3() + "/" + newBooking.getPassenger3() + "/" + str1, String.class);
			if (restresult == "failure") {
				return new ModelAndView("failure", "command", "Invalid Passenger Details");
			}

		}

		ticket.setTotalFare(sum + "");
		ticket.setNoOfSeats(noOfSeats);
		ticketRepository.saveAndFlush(ticket);
		// write a query to decrement the number of seats in Flight_details
		flightRepository.updateSeatsDetails(ticket.getFlight().getFlightId(), noOfSeats);
		model.addAttribute("totalFare", sum);
		model.addAttribute("user", user);
		model.addAttribute("noOfSeats", noOfSeats);
		System.out.println("newBooking" + newBooking);
		return new ModelAndView("process", "command", newBooking);
	}
}
