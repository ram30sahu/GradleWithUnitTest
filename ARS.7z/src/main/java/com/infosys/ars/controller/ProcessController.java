/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infosys.ars.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import com.infosys.ars.domain.SearchFlights;

import com.infosys.ars.domain.CreditCard;

@Controller
public class ProcessController {

	@Autowired
	private RestTemplate restTemplate;
	@Value("${restServer}")
	private String restUrl;	

	@RequestMapping(value = "/SearchFlightsDetails.htm", method = RequestMethod.GET)
	public ModelAndView SearchFlights(ModelMap model) {

		return new ModelAndView("searchFlights", "command", new SearchFlights());
	}

	@RequestMapping(value = "/Payment.htm", method = RequestMethod.GET)
	public ModelAndView makePayment(ModelMap model, @RequestParam("user") String user, @RequestParam("pnr") int pnr,
			@RequestParam("noOfSeats") int noOfSeats) {
		model.addAttribute("user", user);
		model.addAttribute("pnr", pnr);
		model.addAttribute("noOfSeats", noOfSeats);
		return new ModelAndView("payment", "command", new CreditCard());
	}

	@RequestMapping(value = "/pay.htm", method = RequestMethod.POST)
	public ModelAndView processPayment(@Valid @ModelAttribute("command") CreditCard creditCard,
			BindingResult bindingResult, ModelMap model, @RequestParam("fare") String fare,
			@RequestParam("user") String user, @RequestParam("pnr") int pnr, @RequestParam("noOfSeats") int noOfSeats) {
		model.addAttribute("pnr", pnr);
		model.addAttribute("noOfSeats", noOfSeats);
		model.addAttribute("user", user);
		model.addAttribute("fare", fare);
		if (bindingResult.hasErrors()) {
			return new ModelAndView("payment", "command", creditCard);
		} else {
			Boolean validUser = restTemplate.postForObject(restUrl+"/payment/", creditCard, Boolean.class);
			if (validUser == true) {

				model.addAttribute("pnr", pnr);
				model.addAttribute("noOfSeats", noOfSeats);
				model.addAttribute("user", user);
				model.addAttribute("fare", fare);
				return new ModelAndView("paymentSuccess", "command", creditCard);
			}
			//return new ModelAndView("failure", "command", "Invalid credit card details!!!");
		
			model.addAttribute("error", "Invalid credit card details.");
			return new ModelAndView("payment", "command", creditCard);

		}
	}
}