/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.infosys.ars.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.ars.domain.Flights;
import com.infosys.ars.repository.FlightsRepository;

@RestController
@RequestMapping("/flights")
public class FlightRESTService {
	@Autowired
	private FlightsRepository flightsRepository;

	@RequestMapping(value = "/{source}/{destination}/{journeyDate}", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Flights> getFlightDetails(@PathVariable String source, @PathVariable String destination,
			@PathVariable String journeyDate) {

		List<Flights> availableFlights = flightsRepository.findFlightDetails(source, destination, journeyDate);

		return availableFlights;
	}
}