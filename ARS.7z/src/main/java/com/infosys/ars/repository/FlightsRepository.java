package com.infosys.ars.repository;

import java.util.List;

//import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.ars.domain.Flights;

@Repository
public interface FlightsRepository extends JpaRepository<Flights, String> {	 
	 @Query("select f from Flights f where f.source=:source and f.destination=:dest and f.flightAvailableDate=:jdate")
	 List<Flights>  findFlightDetails(@Param("source") String source, @Param("dest") String destination,@Param("jdate") String date);
	 
	 @Modifying(clearAutomatically = true)
	 @Transactional
	 @Query(value="update Flights set seatCount=seatCount-:noOfSeats where flightId=:flightId")
	void updateSeatsDetails(@Param("flightId") String flightId, @Param("noOfSeats") int noOfSeats);
}
