package com.infosys.ars.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.ars.domain.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger, Integer>{

}
