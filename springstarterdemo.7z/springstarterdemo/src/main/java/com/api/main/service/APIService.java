package com.api.main.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.JSONArray;
import org.springframework.stereotype.Service;

@Service
public class APIService {


   public long getFibonacci(long n) {
		{
			if (n <= 1)
				return n;
			return getFibonacci(n-1) + getFibonacci(n-2);
		}

}
	
	public String getReverseWords(String inputString) {
		
		{
			String[] words = inputString.split(" ");
			
			String reverseString = "";
			
			for (int i = 0; i < words.length; i++) 
			{
				String word = words[i];
				
				String reverseWord = "";
				
				for (int j = word.length()-1; j >= 0; j--) 
				{
					reverseWord = reverseWord + word.charAt(j);
				}
				
				reverseString = reverseString + reverseWord + " ";
			}
		return reverseString;

}
}
	public String getTriangleType(int a, int b, int c) {
		String triangleType=null;
		if(a==b && b==c)
		triangleType="Equilateral";

        else if(a >= (b+c) || c >= (b+a) || b >= (a+c) )
		triangleType="Not a triangle";
        else if ((a==b && b!=c ) || (a!=b && c==a) || (c==b && c!=a))
		triangleType="Isosceles";
        else if(a!=b && b!=c && c!=a)
		triangleType="Scalene";
		return triangleType;
    }
	
	
	}
	
