package com.api.main.controller;

import java.util.Arrays;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.api.main.service.APIService;

@RestController
public class APIController {
	@Autowired
	private APIService apiService;
	
	
	@RequestMapping(value="ReverseWords", method=RequestMethod.GET)
	public String getReverseWords(@RequestParam("sentence") @NotNull String inputString ) {
		
		return apiService.getReverseWords(inputString);
	}
	
	@RequestMapping(value="Fibonacci", method=RequestMethod.GET)
	public long getFibonacci(@RequestParam("n") @NotNull long id ) {
		
		return apiService.getFibonacci(id);
	}
	@RequestMapping(value="TriangleType", method=RequestMethod.GET)
	public String getTriangleType(@RequestParam("a") @NotNull int x,@RequestParam("b") @NotNull int y,@RequestParam("c") @NotNull int z) {
		
		return apiService.getTriangleType(x,y,z);
	}
	
	
	@RequestMapping(value="array", method=RequestMethod.POST)
	  @Produces(MediaType.APPLICATION_JSON)
	  @Consumes(MediaType.APPLICATION_JSON)
	  public JSONObject sayPlainTextHello(JSONObject inputJsonObj) throws Exception {
		String input = (String) inputJsonObj.get("input");
	    String output = "The input you sent is :" + input;
	    JSONObject outputJsonObj = new JSONObject();
	    outputJsonObj.put("output", output);
	    System.out.println("Output obj:"+output);
	    return outputJsonObj;
	}
	


}
