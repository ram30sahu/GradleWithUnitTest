package com.infosys.cmi.dao;

import org.springframework.data.repository.CrudRepository;

import com.infosys.cmi.entity.User;

public interface UserDao extends CrudRepository<User, String> {
}
