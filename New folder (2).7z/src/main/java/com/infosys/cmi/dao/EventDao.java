package com.infosys.cmi.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infosys.cmi.entity.Event;

public interface EventDao extends CrudRepository<Event, Long> {
	public List<Event> findByEventTitleLikeAndDeleteFlag(String title, String deleteFlag);
}
