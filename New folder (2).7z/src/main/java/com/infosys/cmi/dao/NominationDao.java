package com.infosys.cmi.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infosys.cmi.entity.Nomination;

public interface NominationDao extends CrudRepository<Nomination, Long> {
	
	public List<Nomination> findByEventId(Long eventId);

	public Nomination findByEventIdAndNomId(Long eventId, Long nomId);
}
