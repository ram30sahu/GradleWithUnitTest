package com.infosys.cmi.dao;

import org.springframework.data.repository.CrudRepository;

import com.infosys.cmi.entity.Nomination;

public interface NominationDao extends CrudRepository<Nomination, Long> {
}
