package com.infosys.cmi.controller;

import javax.persistence.EntityNotFoundException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.infosys.cmi.ApiMessages;

@ControllerAdvice
public class ExceptionControllerAdvice {

	ApiMessages messages;
	
	@ExceptionHandler(EntityNotFoundException.class)
	public ResponseEntity<ApiMessages> entityNotFoundExceptionHandler(EntityNotFoundException entityNotFoundException) {
		messages = new ApiMessages(HttpStatus.NOT_FOUND.value(), entityNotFoundException.getMessage());
		return new ResponseEntity<ApiMessages>(messages, HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<ApiMessages> illegalArgumentExceptionHandler(IllegalArgumentException illegalArgumentException) {
		messages = new ApiMessages(HttpStatus.UNAUTHORIZED.value(), illegalArgumentException.getMessage());
		return new ResponseEntity<ApiMessages>(messages, HttpStatus.UNAUTHORIZED);
	}
	@ExceptionHandler(AccessDeniedException.class)
	public ResponseEntity<ApiMessages> accessDeniedExceptionHandler(AccessDeniedException accessDeniedException) {
		messages = new ApiMessages(HttpStatus.UNAUTHORIZED.value(), accessDeniedException.getMessage());
		return new ResponseEntity<ApiMessages>(messages, HttpStatus.UNAUTHORIZED);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ApiMessages> exceptionHandler(Exception exception) {
		messages = new ApiMessages(HttpStatus.INTERNAL_SERVER_ERROR.value(), exception.getMessage());
		return new ResponseEntity<ApiMessages>(messages, HttpStatus.OK);
	}
}
