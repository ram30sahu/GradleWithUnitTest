package com.infosys.cmi.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.infosys.cmi.ApiMessages;
import com.infosys.cmi.entity.Event;
import com.infosys.cmi.entity.Nomination;
import com.infosys.cmi.service.IEventService;
import com.infosys.cmi.service.INominationService;

@RestController
@RequestMapping("event")
public class EventController {
	@Autowired
	IEventService eventService;
	
	@Autowired
	INominationService nominationService;
				
	@PostMapping("")
	@Secured("ROLE_S")
	public Event addEvent(@RequestBody Event event) {
		return eventService.addEvent(event);
	}
	
	ApiMessages messages;
	
	@PostMapping(value="/upload", produces = MediaType.APPLICATION_JSON_VALUE)
	@PreAuthorize("hasRole('ROLE_S')")
	public ResponseEntity<?> uploadEventImage(@RequestParam("eventImage") MultipartFile eventImage) throws Exception {
		
		messages = new ApiMessages(HttpStatus.OK.value(), eventService.uploadEventImage(eventImage));		
		return new ResponseEntity<ApiMessages>(messages, HttpStatus.OK);		
	}

	@GetMapping("")
	public ResponseEntity<?> getEvents(Event event) {
		
		List<Event> eList = eventService.find(event, new Date());
		return new ResponseEntity<List<Event>>(eList, HttpStatus.OK);	
	}

	@GetMapping("/{eventId}")
	public ResponseEntity<?> getEvent(@PathVariable Long eventId) {
		
		Event event = eventService.getEvent(eventId);
		return new ResponseEntity<Event>(event, HttpStatus.OK);
	}
	
	@PutMapping(value="/{eventId}", produces = "application/json")
	public ResponseEntity<?> updateEvent(@RequestBody Event event, @PathVariable Long eventId) {
		
		Event result = eventService.updateEvent(event, eventId);
		return new ResponseEntity<Event>(result, HttpStatus.OK);		
	}

	@GetMapping(value="/{eventId}/nomination/{nomId}", produces = "application/json")
	public ResponseEntity<?> getNom(@PathVariable Long eventId, @PathVariable Long nomId) throws Exception {
		
		Nomination nomination = nominationService.getNom(eventId, nomId);
		return new ResponseEntity<Nomination>(nomination, HttpStatus.OK);			
	}

	@GetMapping(value="/{eventId}/nomination", produces = "application/json")
	public ResponseEntity<?> getAllNom(@PathVariable Long eventId) throws Exception {
		
		
		List<Nomination> nomList = nominationService.getAllNom(eventId);
		return new ResponseEntity<List<Nomination>>(nomList, HttpStatus.OK);
	}
	
	@PostMapping(value="/{eventId}/nomination", produces = "application/json")
	public ResponseEntity<?> addNom(@RequestBody Nomination nomination, @PathVariable Long eventId) throws Exception {
		
		Nomination nom = nominationService.saveNom(nomination, eventId, null);
		return new ResponseEntity<Nomination>(nom, HttpStatus.OK);
		
	}
	
	@PutMapping(value="/{eventId}/nomination/{nomId}", produces = "application/json")
	public ResponseEntity<?> updateNom(@RequestBody Nomination nomination, @PathVariable Long eventId, @PathVariable Long nomId) throws Exception{

		Nomination nom = nominationService.saveNom(nomination, eventId, nomId);
		return new ResponseEntity<Nomination>(nom, HttpStatus.OK);		
	}
}
