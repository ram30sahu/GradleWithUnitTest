package com.infosys.cmi.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.cmi.entity.Event;
import com.infosys.cmi.entity.Nomination;
import com.infosys.cmi.service.IEventService;
import com.infosys.cmi.service.INominationService;

@RestController
@RequestMapping("event")
public class EventController {
	@Autowired
	IEventService eventService;
	
	@Autowired
	INominationService nominationService;
	
	@PostMapping("")
	@Secured("ROLE_S")
	public Event addEvent(Event event) {
		return eventService.addEvent(event);
	}

	@GetMapping("")
	public List<Event> getEvents(Event event) {
		return eventService.find(event, new Date());
	}

	@GetMapping("/{eventId}")
	public Event getEvent(@PathVariable Long eventId) {
		return eventService.getEvent(eventId);
	}

	@GetMapping("/{eventId}/nomination/{nomId}")
	public Nomination getNom(@PathVariable Long nomId) {
		return nominationService.getNom(nomId);
	}
	
}
