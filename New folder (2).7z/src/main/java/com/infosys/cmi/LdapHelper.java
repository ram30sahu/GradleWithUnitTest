package com.infosys.cmi;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;

import com.infosys.cmi.entity.Nomination;

public class LdapHelper {

	private static Logger logger = Logger.getLogger(LdapHelper.class);

    private static SearchControls constraints;
    
    //the mandatory attributes which are specific to a company’s LDAP
    private static final String[] WANTED_ATTRIBUTES = new String[] {
                    "displayName", "company", "department","l",
                    "mobile", "ipPhone", "name", "cn", 
                    "extensionAttribute1","extensionAttribute2","extensionAttribute3","physicalDeliveryOfficeName"};
    

    static {
                    constraints = new SearchControls();
                    constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
    }
    
    public static Nomination ldapAuth(Nomination nomination) {
        
    	String netid = "[ID]";
        String password = "[Password]";
        DirContext dirContext = null;
        NamingEnumeration<SearchResult> namingEnum = null;                               
        SearchResult search;
        
        if (null != password && !password.isEmpty()) {
        	
        	try {
        		
        		logger.info("inside ldapAuth getting dir context ");
                dirContext = (DirContext)getLDAPConnection(netid, password).lookup("DC=ad,DC=infosys,DC=com");
                logger.info("inside ldapAuth Got dir context ");
                
                // search directory for the email id
                namingEnum = dirContext.search("", "(mail=" + netid + "@infosys.com)", constraints);

                // if the mail id exists, search the corresponding participant id
                if (namingEnum.hasMore()) {
                	search = namingEnum.next();
                    
                    if (search != null) {
                    	
                    	// the attributes 'company' and 'displayName' correspond to user id and display names respectively in the directory.
                        Attributes gotAttributes = (dirContext.getAttributes(search.getName(), WANTED_ATTRIBUTES));
                        
                        //String userId = deriveAttribute("company", gotAttributes);           
                        //String dept = deriveAttribute("department", gotAttributes);         
                        String mobile = deriveAttribute("mobile", gotAttributes);              
                        //String city = deriveAttribute("l", gotAttributes);
                        
                        String name = deriveAttribute("displayName", gotAttributes);
                        String extensionAttribute1 = deriveAttribute("extensionAttribute1", gotAttributes);  //extn
                        String extensionAttribute2 = deriveAttribute("extensionAttribute2", gotAttributes);  //projects
                        String extensionAttribute3 = deriveAttribute("extensionAttribute3", gotAttributes);  //bldg
                        //String baseLocation = deriveAttribute("physicalDeliveryOfficeName", gotAttributes);  
                        
                        nomination.setUserMobile(mobile);
                        nomination.setUserName(name);
                        nomination.setInputText1(extensionAttribute1);
                        nomination.setInputText2(extensionAttribute2);
                        nomination.setInputText3(extensionAttribute3);
                    }
            	}
        	} catch (AuthenticationException e) {
	            logger.info("Incorrect crediantials provided AuthenticationException" + netid);
	            return nomination;
            } catch (NamingException e) {
                logger.info("Incorrect crediantials provided NamingException" + netid);
                return nomination;
            } catch (Exception e) {
                logger.error("Error in LDAP call",e);
                return nomination;
            } finally {
                // Close the context when we're done
                try {
	                if (dirContext != null)
                        dirContext.close();
                } 
                catch (NamingException e) {
                    logger.error("Error while closing LDAP ctx",e);
                }
            }
        } else {
            logger.info("No pwd provided");
            return nomination;
        }
        return nomination;
    }
    
    public static DirContext getLDAPConnection(String userName, String password)
            throws NamingException, AuthenticationException {

    	//Create a java.util.HashTable of environment attributes required to connect to AD
        Hashtable<String, String> env = null;

        // Set up environment for creating initial context
        env = new Hashtable<String, String>(11);

		//Create LdapContext object using environment attributes and control parameters
        env.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
                                             "com.sun.jndi.ldap.LdapCtxFactory");
             
		//pass the LDAP URL to which we have to connect. 
		env.put(javax.naming.Context.PROVIDER_URL, "ldap://192.168.200.57:389/");
        env.put(javax.naming.Context.REFERRAL, "follow");

        //As stated above we should close the connection after some specific amount of time

		env.put("com.sun.jndi.ldap.read.timeout", "2000");
		
		// Authenticate
		env.put(javax.naming.Context.SECURITY_AUTHENTICATION, "simple");
		env.put(javax.naming.Context.SECURITY_PRINCIPAL, "itlinfosys\\"
		                                 + userName);
		env.put(javax.naming.Context.SECURITY_CREDENTIALS, password);
		
		// Create the initial context
		logger.info("trying InitialDirContext dir context ");
		DirContext initCtx = new InitialDirContext(env);
		logger.info("  Got dir context ");
		return initCtx;
           
    }
    
    /**
     * The attribute obtained from the directory search is in the form of String
     * of format 'Attribute: value'. This method derives just the value of the
     * attribute from the String.
     * 
      * @param attribute
     * @param toDerive
     * @return String
     */
     public static String deriveAttribute(String attributeToDerive, Attributes attributes) {
	     //return toDerive.substring(attribute.length() + 2);
	     Attribute attr = attributes.get(attributeToDerive);
	     String str = null;
	     try {
	                     if(attr!=null) str = attr.toString().substring(attributeToDerive.length() + 2);
	     } catch (Exception e) {}
	     return str;
     }
}
