package com.infosys.cmi;

public class Constants {
	
	public static final String USER_ACTIVE = "Y";
	
	public static final String INPUT_REQ_NG = "N";
	
}
