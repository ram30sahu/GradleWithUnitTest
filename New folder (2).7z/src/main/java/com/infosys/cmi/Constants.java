package com.infosys.cmi;

public class Constants {
	
	public static final String USER_ACTIVE = "Y";
	
	public static final String INPUT_REQ_NG = "N";
	
	public static final String NOM_STATUS_SUBMITTED = "S"; 
	
}
