package com.infosys.cmi.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;

@Component
@Entity
public class Nomination {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long nomId;

	@Column(nullable = false)
	private Long eventId;
	
	@Column(length = 240)
	private String inputText1;

	@Column(length = 240)
	private String inputText2;

	@Column(length = 240)
	private String inputText3;
	
	@Column(length = 2000)
	private String inputTextarea1Label;

	@Column(nullable = false, length = 60)
	private String createdBy;

	@Column(nullable = false)
	private Date createdDt;

	@Column(nullable = false, length = 60)
	private String lastUpdatedBy;

	@Column(nullable = false)
	private Date lastUpdatedDt;
	
	@Email
	@Column(length = 60)
	private String userEmailid;

	@Column(length = 120)
	private String userName;

	@Column(length = 20)
	private String userMobile;

	@Column(length = 1)
	private String status;

	public Long getNomId() {
		return nomId;
	}

	public void setNomId(Long nomId) {
		this.nomId = nomId;
	}

	public Long getEventId() {
		return eventId;
	}

	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	public String getInputText1() {
		return inputText1;
	}

	public void setInputText1(String inputText1) {
		this.inputText1 = inputText1;
	}

	public String getInputText2() {
		return inputText2;
	}

	public void setInputText2(String inputText2) {
		this.inputText2 = inputText2;
	}

	public String getInputText3() {
		return inputText3;
	}

	public void setInputText3(String inputText3) {
		this.inputText3 = inputText3;
	}

	public String getInputTextarea1Label() {
		return inputTextarea1Label;
	}

	public void setInputTextarea1Label(String inputTextarea1Label) {
		this.inputTextarea1Label = inputTextarea1Label;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDt() {
		return lastUpdatedDt;
	}

	public void setLastUpdatedDt(Date lastUpdatedDt) {
		this.lastUpdatedDt = lastUpdatedDt;
	}

	public String getUserEmailid() {
		return userEmailid;
	}

	public void setUserEmailid(String userEmailid) {
		this.userEmailid = userEmailid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
