package com.infosys.cmi.entity;

import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.infosys.cmi.Constants;

@Entity
public class Event {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long eventId;

	@Column(nullable = false, length = 120)
	private String eventTitle;

	@Column(length = 120)
	private String hdrImg;

	@Column(length = 60)
	private String anchorEmail;

	@Column(length = 60)
	private String inputText1Label;

	@Column(length = 1)
	@Generated(Constants.INPUT_REQ_NG)
	private String inputText1Req;

	@Column(length = 60)
	private String inputText2Label;

	@Column(length = 1)
	@Generated(Constants.INPUT_REQ_NG)
	private String inputText2Req;
	
	@Column(length = 60)
	private String inputText3Label;

	@Column(length = 1)
	@Generated(Constants.INPUT_REQ_NG)
	private String inputText3Req;

	@Column(length = 60)
	private String inputTextarea1Label;

	@Column(length = 1)
	@Generated(Constants.INPUT_REQ_NG)
	private String inputTextarea1Req;

	@Column(nullable = false, length = 60)
	private String createdBy;

	@Column(nullable = false)
	private Date createdDt;

	@Column(nullable = false, length = 60)
	private String lastUpdatedBy;

	@Column(nullable = false)
	private Date lastUpdatedDt;

	@Column(nullable = false)
	private Date publishStartDt;
	
	@Column(nullable = false)
	private Date publishEndDt;

	@Column(nullable = false)
	private Date nomStartDt;

	@Column(nullable = false)
	private Date nomEndDt;
	
	@Column(length = 240)
	private String message;

	@Column(length = 240)
	private String confirmMsg;

	@Column(length = 1)
	@Generated(Constants.INPUT_REQ_NG)
	private String deleteFlag;

	public Long getEventId() {
		return eventId;
	}

	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}

	public String getEventTitle() {
		return eventTitle;
	}

	public void setEventTitle(String eventTitle) {
		this.eventTitle = eventTitle;
	}

	public String getHdrImg() {
		return hdrImg;
	}

	public void setHdrImg(String hdrImg) {
		this.hdrImg = hdrImg;
	}

	public String getAnchorEmail() {
		return anchorEmail;
	}

	public void setAnchorEmail(String anchorEmail) {
		this.anchorEmail = anchorEmail;
	}

	public String getInputText1Label() {
		return inputText1Label;
	}

	public void setInputText1Label(String inputText1Label) {
		this.inputText1Label = inputText1Label;
	}

	public String getInputText1Req() {
		return inputText1Req;
	}

	public void setInputText1Req(String inputText1Req) {
		this.inputText1Req = inputText1Req;
	}

	public String getInputText2Label() {
		return inputText2Label;
	}

	public void setInputText2Label(String inputText2Label) {
		this.inputText2Label = inputText2Label;
	}

	public String getInputText2Req() {
		return inputText2Req;
	}

	public void setInputText2Req(String inputText2Req) {
		this.inputText2Req = inputText2Req;
	}

	public String getInputText3Label() {
		return inputText3Label;
	}

	public void setInputText3Label(String inputText3Label) {
		this.inputText3Label = inputText3Label;
	}

	public String getInputText3Req() {
		return inputText3Req;
	}

	public void setInputText3Req(String inputText3Req) {
		this.inputText3Req = inputText3Req;
	}

	public String getInputTextarea1Label() {
		return inputTextarea1Label;
	}

	public void setInputTextarea1Label(String inputTextarea1Label) {
		this.inputTextarea1Label = inputTextarea1Label;
	}

	public String getInputTextarea1Req() {
		return inputTextarea1Req;
	}

	public void setInputTextarea1Req(String inputTextarea1Req) {
		this.inputTextarea1Req = inputTextarea1Req;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDt() {
		return lastUpdatedDt;
	}

	public void setLastUpdatedDt(Date lastUpdatedDt) {
		this.lastUpdatedDt = lastUpdatedDt;
	}

	public Date getPublishStartDt() {
		return publishStartDt;
	}

	public void setPublishStartDt(Date publishStartDt) {
		this.publishStartDt = publishStartDt;
	}

	public Date getPublishEndDt() {
		return publishEndDt;
	}

	public void setPublishEndDt(Date publishEndDt) {
		this.publishEndDt = publishEndDt;
	}

	public Date getNomStartDt() {
		return nomStartDt;
	}

	public void setNomStartDt(Date nomStartDt) {
		this.nomStartDt = nomStartDt;
	}

	public Date getNomEndDt() {
		return nomEndDt;
	}

	public void setNomEndDt(Date nomEndDt) {
		this.nomEndDt = nomEndDt;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getConfirmMsg() {
		return confirmMsg;
	}

	public void setConfirmMsg(String confirmMsg) {
		this.confirmMsg = confirmMsg;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

}
