package com.infosys.cmi;

import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import com.infosys.cmi.entity.User;
import com.infosys.cmi.service.IUserService;

import waffle.servlet.WindowsPrincipal;
import waffle.servlet.spi.BasicSecurityFilterProvider;
import waffle.servlet.spi.NegotiateSecurityFilterProvider;
import waffle.servlet.spi.SecurityFilterProvider;
import waffle.servlet.spi.SecurityFilterProviderCollection;
import waffle.spring.NegotiateSecurityFilter;
import waffle.spring.NegotiateSecurityFilterEntryPoint;
import waffle.windows.auth.impl.WindowsAuthProviderImpl;

@Configuration
public class WaffleConfig {
//
    @Bean
    public WindowsAuthProviderImpl waffleWindowsAuthProvider() {
        return new WindowsAuthProviderImpl();
    }
//
    @Bean
    public NegotiateSecurityFilterProvider negotiateSecurityFilterProvider(
            WindowsAuthProviderImpl windowsAuthProvider) {
        return new NegotiateSecurityFilterProvider(windowsAuthProvider);
    }
//
    @Bean
    public BasicSecurityFilterProvider basicSecurityFilterProvider(WindowsAuthProviderImpl windowsAuthProvider) {
        return new BasicSecurityFilterProvider(windowsAuthProvider);
    }
//
    @Bean
    public SecurityFilterProviderCollection waffleSecurityFilterProviderCollection(
            NegotiateSecurityFilterProvider negotiateSecurityFilterProvider,
            BasicSecurityFilterProvider basicSecurityFilterProvider) {
        SecurityFilterProvider[] securityFilterProviders = {
                negotiateSecurityFilterProvider,
                basicSecurityFilterProvider };
        return new SecurityFilterProviderCollection(securityFilterProviders);
    }
//
    @Bean
    public NegotiateSecurityFilterEntryPoint negotiateSecurityFilterEntryPoint(
            SecurityFilterProviderCollection securityFilterProviderCollection) {
        NegotiateSecurityFilterEntryPoint negotiateSecurityFilterEntryPoint = new NegotiateSecurityFilterEntryPoint();
        negotiateSecurityFilterEntryPoint.setProvider(securityFilterProviderCollection);
        return negotiateSecurityFilterEntryPoint;
    }

	@Autowired
    IUserService userService;
    @Bean
    public NegotiateSecurityFilter waffleNegotiateSecurityFilter(SecurityFilterProviderCollection securityFilterProviderCollection) {
        NegotiateSecurityFilter negotiateSecurityFilter = new NegotiateSecurityFilter() {
        	/**
        	 * Override super class, 
        	 *  1.change WindowsPrincipal of waffle to user of CMI.
        	 *  2.reset authorities by access code of CMI, Rule : "ROLE_" + Access Code
        	 */
            protected boolean setAuthentication(final HttpServletRequest request, final HttpServletResponse response,
                    final Authentication authentication) {
            	
				WindowsPrincipal principal =(WindowsPrincipal)authentication.getPrincipal();
				
				String userName = null;
		        String[] userNameDomain = principal.getName().split("\\\\", 2);
		        if (userNameDomain.length == 2) {
		        	userName = userNameDomain[1];
		        } else {
		        	userName = userNameDomain[0];
		        }
		        
		        User user = userService.getUser(userName);
		        if(user == null) {
		        	user = new User();
		        	user.setUserEmailid(userName);
		        	user.setAccessCode("USER");
		        }
		        final User pricipal = user;
		        
		        final Collection<GrantedAuthority> authorities = new ArrayList<>(1);
			    authorities.add(new SimpleGrantedAuthority("ROLE_" + user.getAccessCode()));

            	Authentication auth = new Authentication() {
					private static final long serialVersionUID = 4336091493377096111L;

					@Override
					public String getName() {
						return authentication.getName();
					}

					@Override
					public Collection<? extends GrantedAuthority> getAuthorities() {
						// TODO Auto-generated method stub
						return authorities;
					}

					@Override
					public Object getCredentials() {
						return authentication.getCredentials();
					}

					@Override
					public Object getDetails() {
						return authentication.getCredentials();
					}

					@Override
					public Object getPrincipal() {
						return pricipal;
					}

					@Override
					public boolean isAuthenticated() {
						return authentication.isAuthenticated();
					}

					@Override
					public void setAuthenticated(boolean arg0) throws IllegalArgumentException {
						authentication.setAuthenticated(arg0);
					}
            		
            	};

                SecurityContextHolder.getContext().setAuthentication(auth);;
            	
            	return true;
            }
        };
        // Solution 1:
//       ew NegotiateSecurityFilter() {
//
//			@Override
//			public void doFilter(final ServletRequest req, final ServletResponse res, final FilterChain chain)
//					throws IOException, ServletException {
//
//		        final HttpServletRequest request = (HttpServletRequest) req;
//		        final AuthorizationHeader authorizationHeader = new AuthorizationHeader(request);
//		        
//		        if (!authorizationHeader.isNull()
//		                && securityFilterProviderCollection.isSecurityPackageSupported(authorizationHeader.getSecurityPackage())) {
//
//					super.doFilter(req, res, chain);
//					
//					Authentication auth =  SecurityContextHolder.getContext()
//					    .getAuthentication();
//					if(!auth.isAuthenticated())return;
//					WindowsPrincipal principal =(WindowsPrincipal)auth.getPrincipal();
//					
//					String userName = null;
//			        String[] userNameDomain = principal.getName().split("\\\\", 2);
//			        if (userNameDomain.length == 2) {
//			        	userName = userNameDomain[1];
//			        } else {
//			        	userName = userNameDomain[0];
//			        }
//					User user = userService.getUser(userName);
//					
//					if(user != null) {
//						Collection<GrantedAuthority> ddd = (Collection<GrantedAuthority>)auth.getAuthorities();
//						ddd.add(new SimpleGrantedAuthority("ROLE_"+ user.getAccessCode()));
//					}
//		        	
//		        }else {
//		        	super.doFilter(req, res, chain);
//		        }
//				
//			}
//    		
//    	};
        negotiateSecurityFilter.setProvider(securityFilterProviderCollection);
        
        
        
        return negotiateSecurityFilter;
    }
//    
//    // This is required for Spring Boot so it does not register the same filter twice
    @Bean
    public FilterRegistrationBean waffleNegotiateSecurityFilterRegistration(NegotiateSecurityFilter waffleNegotiateSecurityFilter) {
    	FilterRegistrationBean registrationBean = new FilterRegistrationBean();
    	registrationBean.setFilter(waffleNegotiateSecurityFilter);
    	registrationBean.setEnabled(false);
    	return registrationBean;
    }
//    
}
