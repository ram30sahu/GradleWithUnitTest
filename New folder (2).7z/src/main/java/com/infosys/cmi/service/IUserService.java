package com.infosys.cmi.service;

import org.springframework.stereotype.Service;

import com.infosys.cmi.entity.User;

@Service
public interface IUserService {

	public User addUser(User user);

	public User getUser(String id);

}
