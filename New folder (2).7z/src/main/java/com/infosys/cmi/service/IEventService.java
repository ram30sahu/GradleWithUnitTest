package com.infosys.cmi.service;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.infosys.cmi.entity.Event;

@Service
public interface IEventService {
	public Event getEvent(Long id);
	public Event addEvent(Event event);
	public List<Event> find(Event event, Date currentTime);

}
