package com.infosys.cmi.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.infosys.cmi.entity.Nomination;

@Service
public interface INominationService {
	public Nomination getNom(Long eventid, Long nomId) throws Exception;

	public List<Nomination> getAllNom(Long eventId) throws Exception;
	
	public Nomination saveNom(Nomination nomination, Long eventId, Long nomId) throws Exception;

}
