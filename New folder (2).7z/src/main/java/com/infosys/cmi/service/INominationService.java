package com.infosys.cmi.service;

import org.springframework.stereotype.Service;

import com.infosys.cmi.entity.Nomination;

@Service
public interface INominationService {
	public Nomination getNom(Long id);

}
