package com.infosys.cmi.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.stereotype.Service;

import com.infosys.cmi.dao.EventDao;
import com.infosys.cmi.entity.Event;
import com.infosys.cmi.service.IEventService;

@Service
public class EventService implements IEventService {

	@Autowired
	private EventDao eventDao;

	@Override
	public Event getEvent(Long id) {
		return eventDao.findOne(id);
	}

	@Override
	public Event addEvent(Event event) {
		return eventDao.save(event);
	}

	@Override
	@PostFilter("hasRole('ROLE_S') || (filterObject.publishStartDt <= #current && filterObject.publishEndDt >= #current)")
	public List<Event> find(Event event, Date current) {
		return eventDao.findByEventTitleLikeAndDeleteFlag("%" + event.getEventTitle() + "%", "N");
	}

}
