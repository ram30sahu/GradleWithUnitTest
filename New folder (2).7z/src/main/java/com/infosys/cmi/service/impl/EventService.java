package com.infosys.cmi.service.impl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.infosys.cmi.dao.EventDao;
import com.infosys.cmi.entity.Event;
import com.infosys.cmi.entity.User;
import com.infosys.cmi.service.IEventService;

@Service
public class EventService implements IEventService {

	@Autowired
	private EventDao eventDao;

	private User userDetails;
	
	@Override
	public Event getEvent(Long eventId) {

		userDetails =
				 (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();	
		Event event;
		
		if(userDetails.getAccessCode().equals("S")) {
			
			event = eventDao.findOne(eventId);
			if (event == null)
				throw new EntityNotFoundException("Records doesn't exists for this ID");
			else
				return event;
		}
		else {			
			event = eventDao.findByeventIdAndPublishStartDtAfterAndPublishEndDtBefore(eventId, new Date(), new Date());

			if (event == null)
				throw new EntityNotFoundException("Records doesn't exists for this ID");
			else
				return event;
		}
	}

	@Override
	@PreAuthorize("hasAnyRole('ROLE_S','ROLE_E')")
	public Event updateEvent(Event event, Long eventId) {
		Date date = new Date();
		userDetails =
				 (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();	
		String username =  userDetails.getUserEmailid();
		username = username.contains("\\") ? username.split("\\\\")[1] : username;
		
		if(userDetails.getAccessCode().equals("S")){
			
			event.setEventId(eventId);
			event.setLastUpdatedBy(username);
			event.setLastUpdatedDt(new Timestamp(date.getTime()));			

			return eventDao.save(event);
		}
		else {			
			
	        Event currentEvent = eventDao.findByEventIdAndAnchorEmail(eventId, username.concat("@infosys.com"));
			
	        if (currentEvent != null) {

	        	currentEvent.setEventId(eventId);
				currentEvent.setInputText1Label(event.getInputText1Label());
				currentEvent.setInputText1Req(event.getInputText1Req());
				currentEvent.setInputText2Label(event.getInputText2Label());
				currentEvent.setInputText2Req(event.getInputText2Req());
				currentEvent.setInputText3Label(event.getInputText3Label());
				currentEvent.setInputText3Req(event.getInputText3Req());
				currentEvent.setInputTextarea1Label(event.getInputTextarea1Label());
				currentEvent.setInputTextarea1Req(event.getInputTextarea1Req());
				currentEvent.setLastUpdatedBy(username);
				currentEvent.setLastUpdatedDt(new Timestamp(date.getTime()));
				
				return eventDao.save(currentEvent);
			}
	        else
	        	throw new EntityNotFoundException("Records doesn't found for this ID");
		}
	}

	@Override
	public Event addEvent(Event event) {
		Date date = new Date();

		userDetails =
				 (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username =  userDetails.getUserEmailid();
		username = username.contains("\\") ? username.split("\\\\")[1] : username;
		
		event.setLastUpdatedBy(username);
		event.setLastUpdatedDt(new Timestamp(date.getTime()));
		return eventDao.save(event);
	}

	@Override
	public List<Event> find(Event event, Date current) {
		userDetails =
				 (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<Event> eList;
		
		if(userDetails.getAccessCode().equals("S"))
			eList = (List<Event>) eventDao.findAll();		
		else
			eList = eventDao.findByPublishStartDtBeforeAndPublishEndDtAfter(current, current);
		
		if (eList.isEmpty()) 
			throw new EntityNotFoundException("Records doesn't exists");
		else
			return eList;
	}

	@Override
	public String uploadEventImage(MultipartFile eventImage) throws Exception {

		final List<String> contentTypes = Arrays.asList("image/png", "image/x-png", "image/jpeg");
		final String FOLDER_PATH = "resources/images/";
		
		if(eventImage.isEmpty()) 
			throw new IllegalArgumentException("Please select an image");
		
		else if (!contentTypes.contains(eventImage.getContentType())) {
			throw new RuntimeException("File is not of image type");
			
		}
		else if (Pattern.compile("\\.(jpg|png|jpeg)$").matcher(eventImage.getOriginalFilename()).find()) {
			
			try 
			{
				byte[] bs = eventImage.getBytes();
				Path path = Paths.get(FOLDER_PATH + eventImage.getOriginalFilename());
				Files.write(path, bs);

				return FOLDER_PATH+eventImage.getOriginalFilename();
				
			} catch (Exception exception) {
				throw new Exception("Upload failed");
			}
		}
		else {
			throw new RuntimeException("File is not of image type");
		}
	}
}
