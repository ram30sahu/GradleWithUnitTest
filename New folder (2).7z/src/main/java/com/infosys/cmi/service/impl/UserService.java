package com.infosys.cmi.service.impl;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.infosys.cmi.dao.UserDao;
import com.infosys.cmi.entity.User;
import com.infosys.cmi.service.IUserService;

@Service
@Qualifier("ICMUser")
public class UserService implements IUserService, UserDetailsService {

	@Autowired
	private UserDao userDao;

	public User addUser(User user) {
		return userDao.save(user);
	}

	public User getUser(String id) {
		return userDao.findOne(id);
	}

	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return new UserDetailsAdapter(getUser(userId));
	}
	
	private class UserDetailsAdapter implements UserDetails{
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 7532013854966363072L;

		private UserDetailsAdapter(User user) {
			
		}

		@Override
		public Collection<? extends GrantedAuthority> getAuthorities() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String getPassword() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String getUsername() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean isAccountNonExpired() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isAccountNonLocked() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isCredentialsNonExpired() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isEnabled() {
			// TODO Auto-generated method stub
			return false;
		}
		
	}

}
