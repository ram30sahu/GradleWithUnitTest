package com.infosys.cmi.service.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.infosys.cmi.Constants;
import com.infosys.cmi.LdapHelper;
import com.infosys.cmi.dao.EventDao;
import com.infosys.cmi.dao.NominationDao;
import com.infosys.cmi.entity.Event;
import com.infosys.cmi.entity.Nomination;
import com.infosys.cmi.entity.User;
import com.infosys.cmi.service.INominationService;

@Service
public class NominationService implements INominationService {

	@Autowired
	private NominationDao nominationDao;

	@Autowired
	private EventDao eventDao;
	
	private User userDetails;
	
	@Override
	public Nomination getNom(Long eventId, Long nomId) throws Exception {

		userDetails =
				 (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		String username =  userDetails.getUserEmailid();
		username = username.contains("\\\\") ? username.split("\\\\")[1] : username;
		
        Event event = eventDao.findOne(eventId);
        Nomination nomination = nominationDao.findByEventIdAndNomId(eventId, nomId);
        
        if (nomination == null)
    		throw new EntityNotFoundException("Records doesn't exists for this Id");

        // If user is admin, go ahead
        if(userDetails.getAccessCode().equals("S")) { 
        	return nomination;        	
        }
        // If user is anchor, check if he is the creator of the event
        else if(userDetails.getAccessCode().equals("E") && event.getAnchorEmail().equals(username.concat("@infosys.com"))) {
        	return nomination;
        }
        // If user is a normal user, check if he only nominated for this ID
        else if(userDetails.getAccessCode().equals("USER") && nomination.getCreatedBy().equals(username)) {
        	return nomination;        	
        }
        else
        	throw new AccessDeniedException("Access denied");
	}

	@Override
	public Nomination saveNom(Nomination nomination, Long eventId, Long nomId) {
		Date date = new Date();
		Timestamp timestamp = new Timestamp(date.getTime());
		
		nomination = LdapHelper.ldapAuth(nomination);
		Nomination existingNomination = nomination;
		
		if(nomId != null)
			existingNomination = nominationDao.findOne(nomId);		

		userDetails =
				 (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		String username =  userDetails.getUserEmailid();
		username = username.contains("\\\\") ? username.split("\\\\")[1] : username;
		
		if(userDetails.getAccessCode().equals("S") || userDetails.getAccessCode().equals("E")) {

			if(nomId == null) {
				
				existingNomination.setCreatedBy(username);
				existingNomination.setCreatedDt(timestamp);	
				existingNomination.setEventId(eventId);		
			}
			existingNomination.setNomId(nomId);
			existingNomination.setLastUpdatedBy(username);
			existingNomination.setLastUpdatedDt(timestamp);
			existingNomination.setStatus(Constants.NOM_STATUS_SUBMITTED);		
			existingNomination.setUserEmailid(username.concat("@infosys.com"));
			existingNomination.setUserMobile(nomination.getUserMobile());
			existingNomination.setUserName(nomination.getUserName());
			nominationDao.save(existingNomination);
			
		}
		else {
			
			// A normal user can only update the nomination if he has created the row
			if(nomId != null) {

				if(username.equals(existingNomination.getCreatedBy())) {
					existingNomination.setNomId(nomId);
					existingNomination.setLastUpdatedBy(username);
					existingNomination.setLastUpdatedDt(timestamp);
					existingNomination.setStatus(Constants.NOM_STATUS_SUBMITTED);		
					existingNomination.setUserEmailid(username.concat("@infosys.com"));
					existingNomination.setUserMobile(nomination.getUserMobile());
					existingNomination.setUserName(nomination.getUserName());
					nominationDao.save(existingNomination);
				}
				else
					throw new AccessDeniedException("Permission denied");
			}
			else {
				
				existingNomination.setCreatedBy(username);
				existingNomination.setCreatedDt(timestamp);	
				existingNomination.setEventId(eventId);		
				existingNomination.setNomId(nomId);
				existingNomination.setLastUpdatedBy(username);
				existingNomination.setLastUpdatedDt(timestamp);
				existingNomination.setStatus(Constants.NOM_STATUS_SUBMITTED);		
				existingNomination.setUserEmailid(username.concat("@infosys.com"));
				existingNomination.setUserMobile(nomination.getUserMobile());
				existingNomination.setUserName(nomination.getUserName());
				nominationDao.save(existingNomination);
			}
		}
		return nomination;
	}

	@Override
	public List<Nomination> getAllNom(Long eventId) throws Exception {
		
		userDetails =
				 (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
		String username =  userDetails.getUserEmailid();
		username = username.contains("\\") ? username.split("\\\\")[1] : username;
		
        Event event = eventDao.findOne(eventId);
        List<Nomination> nomList = nominationDao.findByEventId(eventId);
        
        if (nomList.isEmpty())
			throw new EntityNotFoundException("Records doesn't exists"); 
        
        // If user is admin, go ahead
        if(userDetails.getAccessCode().equals("S")) {
        	return nomList;
        }
        // If user is anchor, check if he is the creator of the event
        else if(userDetails.getAccessCode().equals("E") && event.getAnchorEmail().equals(username.concat("@infosys.com"))) {
        	return nomList;    	
        }
        else {
			throw new AccessDeniedException("Access denied");
		}
	}

}
