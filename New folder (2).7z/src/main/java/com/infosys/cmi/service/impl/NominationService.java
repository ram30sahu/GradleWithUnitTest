package com.infosys.cmi.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.cmi.dao.NominationDao;
import com.infosys.cmi.entity.Nomination;
import com.infosys.cmi.service.INominationService;

@Service
public class NominationService implements INominationService {

	@Autowired
	private NominationDao nominationDao;

	@Override
	public Nomination getNom(Long id) {
		return nominationDao.findOne(id);
	}

}
