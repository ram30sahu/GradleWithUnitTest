package com.infosys.cmi.event;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.Charset;
import java.util.Calendar;
import java.util.Date;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.cmi.Application;
import com.infosys.cmi.TestUtils;
import com.infosys.cmi.dao.EventDao;
import com.infosys.cmi.entity.Event;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@WebAppConfiguration
public class EventControllerTests {

    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(),
            Charset.forName("utf8"));

	@Autowired
	private WebApplicationContext context;

	@Autowired
	private EventDao eventDao;

	private MockMvc mockMvc;

	private Event publishedEvent;
	private Event nonpublishedEvent;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders
				.webAppContextSetup(context)
				.apply(springSecurity()).build();
		Date current = new Date();
		Calendar startDate = Calendar.getInstance();
		startDate.setTime(current);
		startDate.add(Calendar.MONTH, -1);
		Calendar endDate = Calendar.getInstance();
		endDate.setTime(current);
		endDate.add(Calendar.MONTH, 1);
		Calendar end2Date = Calendar.getInstance();
		end2Date.setTime(current);
		end2Date.add(Calendar.MONTH, 2);
		
		Event event = new Event();
		event.setEventTitle("published_" + Thread.currentThread().getId());
		event.setInputText1Req("N");
		event.setInputText2Req("N");
		event.setInputText3Req("N");
		event.setInputTextarea1Req("N");
		event.setAnchorEmail("anchorEmail");
		event.setCreatedBy("tester");
		event.setCreatedDt(current);
		event.setLastUpdatedBy("tester");
		event.setLastUpdatedDt(current);
		event.setPublishStartDt(startDate.getTime());
		event.setPublishEndDt(endDate.getTime());
		event.setNomStartDt(current);
		event.setNomEndDt(current);
		event.setDeleteFlag("N");
		publishedEvent = eventDao.save(event);
		
		Event event2 = new Event();
		event2.setEventTitle("published_" + Thread.currentThread().getId());
		event2.setInputText1Req("N");
		event2.setInputText2Req("N");
		event2.setInputText3Req("N");
		event2.setInputTextarea1Req("N");
		event2.setAnchorEmail("anchorEmail");
		event2.setCreatedBy("tester");
		event2.setCreatedDt(current);
		event2.setLastUpdatedBy("tester");
		event2.setLastUpdatedDt(current);
		event2.setPublishStartDt(endDate.getTime());
		event2.setPublishEndDt(end2Date.getTime());
		event2.setNomStartDt(current);
		event2.setNomEndDt(current);
		event2.setDeleteFlag("N");
		nonpublishedEvent = eventDao.save(event2);
	}

	@Test
    @Rollback(true)
	public void testAddEvent() throws Exception {
		ObjectMapper om = new ObjectMapper();

		mockMvc.perform(post("/event").with(authentication(TestUtils.getAuth("ITLINFOSYS\\super.admin01", "S")))
				.contentType(contentType).content(om.writeValueAsString(publishedEvent)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.eventId").value(new BaseMatcher<Long>() {
					@Override
					public boolean matches(Object item) {
						return eventDao.findOne(Long.valueOf(item + "")) != null;
					}
					@Override
					public void describeTo(Description description) {
						
					}

				}));

	}

	@Test
    @Rollback(true)
	public void testUpdateEvent() throws Exception {
		ObjectMapper om = new ObjectMapper();
		mockMvc.perform(put("/event/"+publishedEvent.getEventId()).with(authentication(TestUtils.getAuth("ITLINFOSYS\\super.admin01", "S")))
				.contentType(contentType)
				.content(om.writeValueAsString(publishedEvent)))
		.andExpect(status().isOk());
	}

	@Test
	public void testFindByCommonUser() throws Exception {
		mockMvc.perform(
		get("/event").with(authentication(TestUtils.getAuth("ITLINFOSYS\\some.one", "USER"))))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$[?(@.eventId == "+ publishedEvent.getEventId() +")]").exists())
		.andExpect(jsonPath("$[?(@.eventId == "+ nonpublishedEvent.getEventId() +")]").doesNotExist());
	}

	@Test
	public void testFindBySuperUser() throws Exception {
		mockMvc.perform(get("/event").with(authentication(TestUtils.getAuth("ITLINFOSYS\\\\super.admin01", "S"))))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$[?(@.eventId == "+ publishedEvent.getEventId() +")]").exists())
		.andExpect(jsonPath("$[?(@.eventId == "+ nonpublishedEvent.getEventId() +")]").exists())
		;
	}

//	@Test
	public void testGetEvent() throws Exception {
		mockMvc.perform(get("/event/" + publishedEvent.getEventId()).with(authentication(TestUtils.getAuth("ITLINFOSYS\\\\some.one", "USER"))))
		.andExpect(jsonPath("$.eventId").value(publishedEvent.getEventId()));
	}
	
	@After
	public void cleanup() {
		eventDao.delete(publishedEvent.getEventId());
		eventDao.delete(nonpublishedEvent.getEventId());
	}

}
