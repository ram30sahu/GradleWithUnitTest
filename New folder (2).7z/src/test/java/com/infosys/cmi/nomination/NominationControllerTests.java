package com.infosys.cmi.nomination;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.authentication;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.Charset;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import org.hamcrest.Matchers;

import com.infosys.cmi.Application;
import com.infosys.cmi.TestUtils;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
@WebAppConfiguration
public class NominationControllerTests {

	@Autowired
	private WebApplicationContext webApplicationContext;
		
	private MockMvc mockMvc;
	
	private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
	
	@Before
	public void setUp(){
		this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).apply(springSecurity()).build();
	}
	
	@Test
	public void findAllNominationsBySuperAdmin() throws Exception {
		mockMvc.perform(
				get("/event/1/nomination").with(authentication(TestUtils.getAuth("ITLINFOSYS\\super.admin01", "S"))))
				.andExpect(status().isOk())
				.andDo(MockMvcResultHandlers.print())
				.andExpect(jsonPath("$[?(@.nomId == 1)]").exists());
	}
	
	@Test
	public void findAllNominationByAnchor() throws Exception {
		mockMvc.perform(
			get("/event/3/nomination").with(authentication(TestUtils.getAuth("super.admin01", "E"))))
			.andExpect(status().isOk())
			.andDo(MockMvcResultHandlers.print())
			.andExpect(content().string(Matchers.containsString("\"nomId\":3")));
	}
	
	@Test
	public void findAllNominationByUser() throws Exception {
		mockMvc.perform(
			get("/event/3/nomination").with(authentication(TestUtils.getAuth("super.admin01", "USER"))))
			.andExpect(status().isConflict())
			.andDo(MockMvcResultHandlers.print());
	}
	
	@Test
	public void findNominationBySuperAdminUsingNomId() throws Exception {
		mockMvc.perform(
			get("/event/1/nomination/1").with(authentication(TestUtils.getAuth("super.admin01", "S"))))
			.andExpect(status().isOk())
			.andDo(MockMvcResultHandlers.print())
			.andExpect(content().string(Matchers.containsString("\"nomId\":1")));
	}	

	@Test
	public void findNominationByAnchorUsingNomId() throws Exception {
		mockMvc.perform(
			get("/event/3/nomination/5").with(authentication(TestUtils.getAuth("super.admin01", "E"))))
			.andExpect(status().isOk())
			.andDo(MockMvcResultHandlers.print())
			.andExpect(jsonPath("$.nomId", Matchers.is(5)));
	}

	@Test
	public void findNominationByUser() throws Exception {
		mockMvc.perform(
			get("/event/3/nomination/5").with(authentication(TestUtils.getAuth("super.admin01", "USER"))))
			.andExpect(status().isOk())
			.andDo(MockMvcResultHandlers.print())
			.andExpect(content().string(Matchers.containsString("\"nomId\":5")));
	}

	@Test
	public void addNominationByUserUsingNomId() throws Exception {
		
		mockMvc.perform(
			post("/event/3/nomination").with(authentication(TestUtils.getAuth("super.admin01", "USER")))
			.contentType(contentType).content("{\"nomId\":6,\"eventId\":3,\"inputText1\":null,\"inputText2\":null,\"inputText3\":null,\"inputTextarea1Label\":null,\"createdBy\":\"super.admin01\",\"createdDt\":1517300502967,\"lastUpdatedBy\":\"super.admin01\",\"lastUpdatedDt\":1517300502967,\"userEmailid\":\"super.admin01@infosys.com\",\"userName\":\"super.admin01\",\"userMobile\":\"8459475848\",\"status\":\"S\"}"))
			.andExpect(status().isOk())
			.andDo(MockMvcResultHandlers.print())
			.andExpect(content().string(Matchers.containsString("\"eventId\":3")));
	}
	
	@Test
	public void updateNominationbyUser() throws Exception {
		mockMvc.perform(
			put("/event/3/nomination/6").with(authentication(TestUtils.getAuth("super.admin01", "USER")))
			.contentType(contentType).content("{\"nomId\":6,\"eventId\":3,\"inputText1\":\"Test Data\",\"inputText2\":null,\"inputText3\":null,\"inputTextarea1Label\":null,\"createdBy\":\"super.admin01\",\"createdDt\":1517300502967,\"lastUpdatedBy\":\"super.admin01\",\"lastUpdatedDt\":1517300502967,\"userEmailid\":\"super.admin01@infosys.com\",\"userName\":\"super.admin01\",\"userMobile\":\"8459475848\",\"status\":\"S\"}"))
			.andDo(MockMvcResultHandlers.print())
			.andExpect(status().isOk())
			.andExpect(content().string(Matchers.containsString("\"inputText1\":\"Test Data\"")));
	}
}
