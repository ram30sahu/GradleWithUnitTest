package com.infosys.cmi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.infosys.cmi.entity.User;

public class TestUtils {

	public static Authentication getAuth(final String userId, String accessCode){
		User user = new User();
		user.setUserEmailid(userId);
		user.setAccessCode(accessCode);
		
		List<GrantedAuthority> authList = new ArrayList<>();
		authList.add(new SimpleGrantedAuthority("ROLE_"+accessCode));
		
		Authentication auth = new Authentication() {
			/**
			 * 
			 */
			private static final long serialVersionUID = -8365842692718213529L;

			@Override
			public String getName() {
				// TODO Auto-generated method stub
				return userId;
			}

			@Override
			public Collection<? extends GrantedAuthority> getAuthorities() {
				// TODO Auto-generated method stub
				return authList;
			}

			@Override
			public Object getCredentials() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public Object getDetails() {
				// TODO Auto-generated method stub
				return user;
			}

			@Override
			public Object getPrincipal() {
				// TODO Auto-generated method stub
				return user;
			}

			@Override
			public boolean isAuthenticated() {
				// TODO Auto-generated method stub
				return true;
			}

			@Override
			public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
				
			}
			
		};
		return auth;
	}
}
